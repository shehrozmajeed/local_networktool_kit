from PyQt5.QtWidgets import QMainWindow, QTabWidget
from gui.recon_tab import ReconTab
from gui.sniff_tab import SniffTab
from gui.mitm_tab import MITMTab
from gui.output_tab import OutputTab

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Local Network Toolkit")
        self.resize(1000, 700)

        tabs = QTabWidget()
        tabs.addTab(ReconTab(), "Recon")
        tabs.addTab(SniffTab(), "Sniffing")
        tabs.addTab(MITMTab(), "MITM")
        tabs.addTab(OutputTab(), "Output")

        self.setCentralWidget(tabs)
