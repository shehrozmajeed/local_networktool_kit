from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QTextEdit
from reports.report_generator import generate_pdf_report

class OutputTab(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()
        self.report_data = []

        self.text_output = QTextEdit()
        self.text_output.setReadOnly(True)

        self.btn_generate = QPushButton("Generate PDF Report")
        self.btn_generate.clicked.connect(self.generate_report)

        self.layout.addWidget(self.text_output)
        self.layout.addWidget(self.btn_generate)
        self.setLayout(self.layout)

    def generate_report(self):
        filename = "reports/network_report.pdf"
        generate_pdf_report(filename, self.report_data or ["No data to report."])
        self.text_output.append(f"Report saved to {filename}")
