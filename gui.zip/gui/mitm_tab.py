from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLineEdit, QLabel
from core.mitm import arp_spoof
import threading

class MITMTab(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()

        self.target_input = QLineEdit()
        self.gateway_input = QLineEdit()

        self.btn_spoof = QPushButton("Start ARP Spoofing")
        self.btn_spoof.clicked.connect(self.start_spoof)

        self.layout.addWidget(QLabel("Target IP:"))
        self.layout.addWidget(self.target_input)

        self.layout.addWidget(QLabel("Gateway IP:"))
        self.layout.addWidget(self.gateway_input)

        self.layout.addWidget(self.btn_spoof)
        self.setLayout(self.layout)

    def start_spoof(self):
        target = self.target_input.text()
        gateway = self.gateway_input.text()
        thread = threading.Thread(target=arp_spoof, args=(target, gateway))
        thread.daemon = True
        thread.start()

