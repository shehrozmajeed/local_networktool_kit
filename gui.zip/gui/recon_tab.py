from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QTextEdit
from PyQt5.QtCore import QThread, pyqtSignal
from core.scanner import get_local_ip, get_subnet, ping_host


class ScanThread(QThread):
    result_signal = pyqtSignal(str)

    def run(self):
        local_ip = get_local_ip()
        if not local_ip:
            self.result_signal.emit("[❌] Could not detect local IP address.")
            return

        try:
            network = get_subnet(local_ip)
            for ip in network.hosts():
                ip_str = str(ip)
                if ping_host(ip_str):
                    self.result_signal.emit(f"[✅] Host alive: {ip_str}")
        except Exception as e:
            self.result_signal.emit(f"[ERROR] {str(e)}")


class ReconTab(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout()
        self.output = QTextEdit()
        self.output.setReadOnly(True)

        self.btn_scan = QPushButton("Scan Local Network")
        self.btn_scan.clicked.connect(self.run_scan)

        layout.addWidget(self.btn_scan)
        layout.addWidget(self.output)
        self.setLayout(layout)

        self.thread = None

    def run_scan(self):
        self.output.append("🔍 Starting scan...\n")
        self.thread = ScanThread()
        self.thread.result_signal.connect(self.display_result_line)
        self.thread.start()

    def display_result_line(self, result):
        self.output.append(result)
