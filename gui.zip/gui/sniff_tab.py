from PyQt5.QtWidgets import QWidget, QVBoxLayout, QPushButton, QTextEdit
from PyQt5.QtCore import QThread, pyqtSignal
from core.sniffer import start_sniffing


class SniffThread(QThread):
    result_signal = pyqtSignal(list)

    def run(self):
        packets = start_sniffing(count=20)
        summaries = []
        try:
            for pkt in packets:
                summaries.append(pkt.summary())
        except Exception as e:
            summaries.append(f"[ERROR] {str(e)}")

        self.result_signal.emit(summaries)


class SniffTab(QWidget):
    def __init__(self):
        super().__init__()
        self.layout = QVBoxLayout()
        self.output = QTextEdit()
        self.output.setReadOnly(True)

        self.btn_start = QPushButton("Start Sniffing")
        self.btn_start.clicked.connect(self.sniff)

        self.layout.addWidget(self.btn_start)
        self.layout.addWidget(self.output)
        self.setLayout(self.layout)

        self.thread = None

    def sniff(self):
        self.output.append("📡 Sniffing started...\n")
        self.thread = SniffThread()
        self.thread.result_signal.connect(self.display_packets)
        self.thread.start()

    def display_packets(self, summaries):
        if summaries:
            self.output.append("\n".join(summaries))
        else:
            self.output.append("⚠️ No packets captured or sniffing failed.\n")

