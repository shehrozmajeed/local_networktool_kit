from scapy.all import sniff

def start_sniffing(iface=None, count=50):
    """
    Sniff network packets. If iface is None, default interface is used.
    """
    try:
        packets = sniff(count=count, iface=iface)
        return packets
    except Exception as e:
        return [f"[ERROR] {str(e)}"]
