import platform
import subprocess
import socket
import ipaddress


def get_local_ip():
    """
    Get the actual LAN IP address (not loopback).
    """
    try:
        # Use a UDP socket to get local IP without sending data
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return None


def get_subnet(ip):
    """
    Return a /24 subnet based on the provided local IP.
    """
    return ipaddress.ip_network(ip + '/24', strict=False)


def ping_host(ip):
    """
    Ping a given IP address once.
    Returns True if the host is reachable, False otherwise.
    Works on Windows, Linux, macOS.
    """
    count_flag = '-n' if platform.system().lower() == 'windows' else '-c'
    command = ['ping', count_flag, '1', ip]

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )
        return result.returncode == 0
    except Exception:
        return False
