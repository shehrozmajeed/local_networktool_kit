import json
import os

CONFIG_PATH = "config/scan_profiles.json"

def load_profiles():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r") as f:
            return json.load(f)
    return {}

def save_profiles(profiles):
    with open(CONFIG_PATH, "w") as f:
        json.dump(profiles, f, indent=4)
