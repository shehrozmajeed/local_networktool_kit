from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

def generate_pdf_report(filename, data):
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4
    c.drawString(100, height - 100, "Network Scan Report")
    y = height - 120
    for line in data:
        c.drawString(100, y, line)
        y -= 20
    c.save()
